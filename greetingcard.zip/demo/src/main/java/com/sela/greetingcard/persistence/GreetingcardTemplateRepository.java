package com.sela.greetingcard.persistence;

import com.sela.greetingcard.business.model.GreetingcardTemplate;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GreetingcardTemplateRepository extends CrudRepository<GreetingcardTemplate, Long> {
}
