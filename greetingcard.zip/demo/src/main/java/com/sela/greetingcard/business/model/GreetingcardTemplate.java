package com.sela.greetingcard.business.model;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class GreetingcardTemplate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String category;
    String greeting;
    String closure;

    public GreetingcardTemplate() {
    }

    public GreetingcardTemplate(String category, String greeting, String closure) {
        this.category = category;
        this.greeting = greeting;
        this.closure = closure;
    }

    public Long getId(){
        return this.id;
    }
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getGreeting() {
        return greeting;
    }

    public void setGreeting(String greetingPart1) {
        this.greeting = greetingPart1;
    }

     public String getClosure() {
        return closure;
    }

    public void setClosure(String closure) {
        this.closure = closure;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GreetingcardTemplate that = (GreetingcardTemplate) o;
        return id.equals(that.id) &&
                category.equals(that.category) &&
                greeting.equals(that.greeting) &&
                Objects.equals(closure, that.closure);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, category, greeting, closure);
    }

    @Override
    public String toString() {
        return "Template{" +
                "Id='" + id + '\'' +
                "category='" + category + '\'' +
                ", greeting='" + greeting + '\'' +
                ", closure='" + closure + '\'' +
                '}'+"\n";
    }
}
