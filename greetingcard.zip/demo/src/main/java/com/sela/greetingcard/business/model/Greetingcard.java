package com.sela.greetingcard.business.model;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
public class Greetingcard  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Date date;
    private String to;
    private String sender;

    @ManyToOne
    @JoinColumn(name = "template_id")
    private GreetingcardTemplate template;

    public Greetingcard() {
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public GreetingcardTemplate getTemplate() {
        return template;
    }

    public void setTemplate(GreetingcardTemplate template) {
        this.template = template;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Greetingcard that = (Greetingcard) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(date, that.date) &&
                Objects.equals(to, that.to) &&
                Objects.equals(sender, that.sender);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, date, to, sender);
    }

    @Override
    public String toString() {
        return "Card{" +
                ", cardDate=" + date +
                ", to='" + to + '\'' +
                ", from='" + sender + '\'' +
                '}';
    }

}
