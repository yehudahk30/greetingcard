package com.sela.greetingcard.persistence;

import com.sela.greetingcard.business.model.Greetingcard;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GreetingcardRepository extends CrudRepository<Greetingcard, Long> {
}
