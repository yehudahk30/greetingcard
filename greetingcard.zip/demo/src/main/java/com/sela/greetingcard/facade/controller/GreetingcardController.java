package com.sela.greetingcard.facade.controller;

import com.sela.greetingcard.MyRunner;
import com.sela.greetingcard.business.model.Greetingcard;
import com.sela.greetingcard.business.model.GreetingcardTemplate;
import com.sela.greetingcard.business.service.GreetingcardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/greetingCard")
public class GreetingcardController {

    private static final Logger logger = LoggerFactory.getLogger(GreetingcardController.class);

    @Autowired
    private GreetingcardService greetingcardService;

    @GetMapping("/catalog")
    public List<GreetingcardTemplate> allGreetingcards(){
        List<GreetingcardTemplate> list = greetingcardService.findAll();
        return list;
    }


    @PostMapping(value = "/{category}", consumes = "application/json", produces = "application/json")
    public Greetingcard save(@PathVariable String category, @RequestBody Greetingcard card){
        List<GreetingcardTemplate> templates = allGreetingcards();
        GreetingcardTemplate requestedTemp = templates.stream().filter(template -> template.getCategory().equals(category)).findFirst().orElse(null);
        if(requestedTemp == null && isInputVarLong(category)){
            requestedTemp = greetingcardService.find(Long.decode(category));
        }
        if(requestedTemp != null) {
            Greetingcard cardToSave = fillCardTemplate(requestedTemp, card);
            return greetingcardService.save(cardToSave);
        }else{
            logger.error("no ruch template "+category);
        }
        //else
        return null;
    }

    private Greetingcard fillCardTemplate(GreetingcardTemplate requestedTemp, Greetingcard card) {
        card.setTemplate(requestedTemp);
        return  card;
    }

    @PutMapping
    public GreetingcardTemplate save(@RequestBody GreetingcardTemplate template){
        return greetingcardService.saveTemplate(template);
    }

    private boolean isInputVarLong(String category) {
        Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
        if (category == null) {
            return false;
        }
        return pattern.matcher(category).matches();
    }
}
