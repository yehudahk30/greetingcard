package com.sela.greetingcard.business.service;

import com.sela.greetingcard.business.model.Greetingcard;
import com.sela.greetingcard.business.model.GreetingcardTemplate;
import com.sela.greetingcard.persistence.GreetingcardRepository;
import com.sela.greetingcard.persistence.GreetingcardTemplateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GreetingcardService {

    @Autowired
    private GreetingcardTemplateRepository templateRepository;

    @Autowired
    private GreetingcardRepository cardRepository;

    public List<GreetingcardTemplate> findAll(){
        Iterable<GreetingcardTemplate> allGreetingCards = templateRepository.findAll();

        List<GreetingcardTemplate> greetingCards = new ArrayList<>();
        allGreetingCards.forEach(greeting -> greetingCards.add(greeting));

        return greetingCards;
    }

    public GreetingcardTemplate saveTemplate(GreetingcardTemplate card){
        return templateRepository.save(card);
    }

    public Greetingcard save(Greetingcard card){
        return cardRepository.save(card);
    }

    public GreetingcardTemplate find(Long id){
        return templateRepository.findById(id).orElse(null);
    }

}
