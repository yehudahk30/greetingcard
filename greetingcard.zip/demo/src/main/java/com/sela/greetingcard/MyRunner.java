package com.sela.greetingcard;

import com.sela.greetingcard.business.model.GreetingcardTemplate;
import com.sela.greetingcard.persistence.GreetingcardTemplateRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;

@Component
public class MyRunner implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(MyRunner.class);

    @Autowired
    private GreetingcardTemplateRepository templateRepository;

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        logger.info("********** initializing templates");

        GreetingcardTemplate template = null;
        template = new GreetingcardTemplate("love", "I want you to know I love you. I always think about you", "with love");
        templateRepository.save(template);

        template = new GreetingcardTemplate("sorry", "I am so sorry. I truely regret whatI have done. I love you very much", "yours");
        templateRepository.save(template);

        template = new GreetingcardTemplate("anniversary ", "Dear love, another year past and we are still together. I wish for us many more years together ", "always yours");
        templateRepository.save(template);

        template = new GreetingcardTemplate("military ", "You are so big and you are going to the army. Wish you all the best, and take it easy ", "miss you");
        templateRepository.save(template);

        templateRepository.findAll();
    }
}
