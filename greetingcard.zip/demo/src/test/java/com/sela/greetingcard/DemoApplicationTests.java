package com.sela.greetingcard;

import com.sela.greetingcard.facade.controller.GreetingcardController;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class GreetingApplicationTests {

    private MockMvc mockMvc;

    @Before
    public void setup(){
        this.mockMvc = MockMvcBuilders.standaloneSetup(new GreetingcardController()).build();
    }

    @Test
    public void testGreetingcardCatalog() throws Exception {
        this.mockMvc.perform(get("/greetingCard/catalog")).andExpect(status().isOk())
                .andExpect(content().json("[{\"category\":\"love\",\"greeting\":\"I want you to know I love you. I always think about you\",\"closure\":\"with love\"},\\n{\"category\":\"sorry\",\"greeting\":\"I am so sorry. I truely regret whatI have done. I love you very much\",\"closure\":\"yours\"},{\"category\":\"anniversary \",\"greeting\":\"Dear love, another year past and we are still together. I wish for us many more years together \",\"closure\":\"always yours\"},{\"category\":\"military \",\"greeting\":\"You are so big and you are going to the army. Wish you all the best, and take it easy \",\"closure\":\"miss you\"}]"));
    }
//	@Test
//	void contextLoads() {
//		Assert.assertTrue(true);
//	}

}
